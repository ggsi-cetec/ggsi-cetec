//Elementos da página de produtos
export const ELEMENTS ={
    titulo:".title"
}