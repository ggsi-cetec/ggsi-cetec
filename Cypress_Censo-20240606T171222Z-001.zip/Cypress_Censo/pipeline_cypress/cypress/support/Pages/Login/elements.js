//Elementos da página de login
export const ELEMENTS ={
    url: "https://www.saucedemo.com/",
    campoUsername: "#user-name",
    campoPassword: "#password",
    botaoLogin: "#login-button"
}