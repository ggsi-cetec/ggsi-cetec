describe('Testes automatizado Censo 2023', function() {
    beforeEach(function() {
        cy.visit('https://censo.educ.rec.br/homologacao/');
    
    });

    it('Validar botão "RECADASTRE-SE" e validar campos no formulário do censo ', function() {
        cy.get('.btn-censo').click();
        cy.get('input[name = "nome"]').type('TESTE AUTOMATIZADO CYPRESS');
        cy.get('select[name = "residencia"]').select('Rural');
        cy.get('input[name = "celular"]').type("81999999999");
        cy.get('input[name = "cpf"]').type('02049285400');
        cy.get('input[name = "rg"]').type('7546511');
        cy.get('select[name = "naturalidade"]').select('PERNAMBUCO');
        cy.get('input[name = "dataDeNascimento"]').type('1976-11-29');
        cy.get('input[name = "cep"]').type('50830405');
        cy.get('select[formcontrolname = "sexo"]').select('Masculino');
        cy.get('input[name = "endereco"]').type('RUA DA PALMA');
        cy.get('input[name = "numero"]').type('5');
        cy.get('input[name = "complemento"]').type('Ladeira sobe e desce');
        cy.get('select[name = "uf"]').select('PE');
        cy.get('select[name = "tipoDoEndereco"]').select("RUA");
        cy.get(':nth-child(1) > .ng-select-searchable > .ng-select-container > .ng-value-container > .ng-input').type('RECIFE');
        cy.get('.ng-option-label').click();
        cy.get(':nth-child(2) > .ng-select-searchable > .ng-select-container').type('RECIFE');
        cy.get('.ng-option-label').click();
        cy.get('select[name = "codBairro"]').select('779');
        cy.get('input[name = "nomeDaMae"]').type('Mãe do CYPRESS');
        cy.get('input[name = "nomeDoPai"]').type('Pai do CYPRESS');
        cy.get('input[name = "email"]').type('teste@cypress.com');
        cy.get('select[name = "raca"]').select('Pardo (a)');
        cy.get('select[name = "escolaridade"]').select('Superior completo');
        cy.get('select[name = "estadoCivil"]').select('Casado(a)');
        cy.get('select[name = "nacionalidade"]').select('Brasileiro Nato');
        cy.get('input[name = "nomeDoConjuge"]').type('Cônjuge do CYPRESS');
        cy.get('.form-check-input').click();
        cy.get('.btn').click();

        //VALIDAÇÃO DO FORMULÁRIO VÍNCULO PROFISSIONAL
        cy.get('input[name = "Matricula"]').type('627400');
        cy.get('select[name = "TipoProfessor"]').select('Docente');
        cy.get('select[name = "FuncaoProfessor"]').select('Assistente de Docente');
        cy.get('.col > .ng-select-searchable > .ng-select-container > .ng-value-container > .ng-input > input').type('ASSISTENTE DE INFORMÁTICA');
        cy.get('.ng-option-label').click();
        cy.get('select[name = "RegimeDeContratacao"]').select('Concursado/efetivo/estável');
        cy.get('select[name = "EstagioProbatorio"]').select('Não');
        cy.get('select[name = "CodigoDoTipoDeVinculo"]').select('Efetivo');
        cy.get('select[name = "CodigoDaCategoria"]').select('ADM');
        cy.get('.mb-3.ng-select-searchable > .ng-select-container > .ng-value-container > .ng-input > input').type('Informática');
        cy.get('.ng-option-label').click();
        cy.get(':nth-child(11) > .form-select').select('Sim');
        cy.get(':nth-child(1) > .ng-select-searchable > .ng-select-container > .ng-value-container > .ng-input > input').type('RECIFE');
        cy.get('.ng-option-label').click();
        cy.get('select[name = "MunicipioOrigemUF"]').select('PE');
        cy.get('select[name = "EsferaOrgaoCedido"]').select('1 - Municipal');
        cy.get('select[name = "Deficiencia"]').select('Não')
        cy.get('input[type = "checkbox"]').click();
        cy.get('.btn-link').click();
        cy.wait(2000);
        cy.get('.d-grid > .btn').click()
        cy.wait(2000);
        cy.get('.d-grid > .btn').click()

        //FORMAÇÃO PROFISSIONAL 1/3
        cy.get('select[name = "licenciatura"]').select('Sim');
        cy.get('select[name = "identificacaoDoCurso"]').select('Formação');
        cy.get('select[name = "situacaoDoCurso"]').select('Concluído');
        cy.get(':nth-child(3) > div[_ngcontent-ng-c435605563=""] > .ng-select-searchable > .ng-select-container > .ng-value-container > .ng-input > input').type('866-FACULDADE DE INFORMATICA DE CUIABA');
        cy.get('.ng-option-label').click();
        cy.get(':nth-child(4) > .ng-select-searchable > .ng-select-container > .ng-value-container > .ng-input > input').type('146F05-Informática - Licenciatura');
        cy.get('.ng-option-label').click();
        cy.get('input[name = "inicioDoCurso"]').type('1997-02-02');
        cy.get(':nth-child(2) > .form-control').click() //clicando no ícone calendário
        cy.get('input[name = "terminoDoCurso"]').type('2001-07-07');
        cy.get('.ng-touched').select('Sim');
        //cy.get('select[name = "instituicaoPublica")]').select('Sim');
        //cy.get(':nth-child(2) > .form-control').()

        
        
        
       




    
    });
    
});