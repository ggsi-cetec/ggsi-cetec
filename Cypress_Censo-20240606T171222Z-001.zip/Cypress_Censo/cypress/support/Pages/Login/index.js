/// <reference  types="cypress" />

import { timeout } from 'async';

import 'cypress-iframe';

const el=require('./elements').ELEMENTS;
const THREE_SECONDS_IN_MS = 3000


class  Login  {

    clickcaptcha(){
      cy.wain(2000);
      //cy.wrap($body).find('.rc-anchor-checkbox[aria-checked="true"]').should('exist'); //Aguarda até que o Recaptcha seja preenchido
      cy.get(el.CAPTCHA).check() //clicando no captcha não sou robô
    }   

    executeLogin(){
      // arrange
      var username = 'cleiton.teixeira@truechange.com.br'

      // act
      cy.wait(4000)
        cy.get(el.LOGINFIELD,{timeout:5000}).type(username)
        cy.get(el.PASSWORDFIELD).type('Abc123') //buscando pelo nome final do ID
        //cy.get(el.VIEWPASSWORD).click()
        //cy.get(el.REMEMBERCHECK).click() //selecionar checkbox lembrar-me
        cy.get(el.SIGNBUTTON).click() //clicar no botão entrar
        cy.get(el.MENUBUTTON).click() //menu button
        cy.get(el.LOGOUTLABEL).click()  //deslogando da página

        // assert
        cy.get(el.LOGINFIELD).should('be.visible', username)
        cy.wait(4000)

    }

    executeLoginInvalid(){
      // arrange
      var msg = 'O login ou senha que você digitou está incorreto'
      var username = 'cleiton.teixeira@truechange.com.br'

      // act
    cy.wait(2000)
    cy.get(el.LOGINFIELD,{timeout:5000}).type(username)
    cy.get(el.PASSWORDFIELD).type('Abc124') //buscando pelo nome final do ID
    cy.get(el.VIEWPASSWORD).click() //Ao clicar no olho o sistema deverá exibir a senha
    cy.get(el.REMEMBERCHECK).click() //selecionar checkbox lembrar-me
    cy.get(el.SIGNBUTTON).click() // Clicar no botão de login

    //assert
    cy.get(el.VALIDATIONMESSAGE).should('be.visible', msg)
    cy.wait(3000)
    
    }

    remember(){
      //arrange
      var username = 'cleiton.teixeira@truechange.com.br'

      //act
    cy.wait(3000)
    cy.get(el.LOGINFIELD,{timeout:5000}).type(username)
    cy.get(el.PASSWORDFIELD).type('Abc123') //buscando pelo nome final do ID
    cy.get(el.VIEWPASSWORD).click() // Ao clicar no olho o sistema deverá exibir a senha
    cy.get(el.REMEMBERCHECK).click() //selecionar checkbox lembrar-me
    cy.get(el.SIGNBUTTON).click()  // Clicar no botão login
    cy.get(el.MENUBUTTON).click() //menu button
    cy.get(el.LOGOUTLABEL).click()  //deslogando da página

    // assert
    cy.get(el.REMEMBERCHECK).should('be.visible').check()
     cy.get(el.LOGINFIELD).should('have.value', username)
    cy.wait(3000)
    
    }

    forgotPassword(){
      //arrange
      var username = 'cleiton.teixeira@truechange.com.br'

      //act
    cy.wait(3000)
    cy.get(el.FORGOTLINK,{timout:5000}).click() //clicando no link "Esqueceu a senha?"
    cy.get(el.EMAILFIELD).find('input').type(username) //confirmando o email cadastrado
    cy.get(el.RESETBUTTON).click() //clicando na opção "Redefinir Senha"
    cy.wait(3000)
    cy.get(el.GOTOLOGINPAGE).click()  //deslogando da página
    }

    cancelPassword(){
      //arrange
      var username = 'cleiton.teixeira@truechange.com.br'

      //act
    cy.wait(2000)
    cy.get(el.FORGOTLINK,{timout:5000}).click() //clicando no link "Esqueceu a senha?"
    cy.get(el.EMAILFIELD).find('input').type(username) //confirmando o email cadastrado
    cy.get(el.CANCELPASSWORDRESET).click() //cancela redefinição de senha e volta pra tela inicial da página
    cy.wait(2000)
    }

    alertAddressEmail(){
      var usarname = 'cleitontrue.com'
    cy.wait(2000)
    cy.get(el.FORGOTLINK,{timout:5000}).click()  //clicando no link "Esqueceu a senha"
    cy.get(el.EMAILFIELD).find('input').type(usarname)
    cy.get(el.RESETBUTTON).click()
    cy.get(el.ALERTADDRESSEMAIL).should('be.visible') 
    }

    signUpButton(){
      //arrange
      //var username = 'Guilherme Lima'
      //var useremail = 'producoespainho@gmail.com'

      //act
    cy.wait(2000)
    cy.get(el.SIGNUPBUTTON,{timout:5000}).click() //Faça seu cadastro
    cy.get(el.NAMEFIELD).find('input').type('Guilherme Lima')  // preemcher campo nome
    cy.get(el.EMAILFIELD).find('input').type('producoespainho@gmail.com') //preencher campo E-mail
    cy.get(el.CONTINUEREGISTRATION).click() //Confirmar clicando em cadastrar    
    cy.wait(2000)
    cy.get(el.GOTOLOGINPAGE).click() //voltando pra tela inici al de login
    }
    
    cancelregistration(){
      cy.wait(2000)
      cy.get(el.SIGNUPBUTTON,{timout:5000}).click() //Faça seu cadastro
      cy.get(el.NAMEFIELD).find('input').type('Guilherme Lima')  // preemcher campo nome
      cy.get(el.EMAILFIELD).find('input').type('producoespainho@gmail.com') //preencher campo E-mail
      cy.get(el.CANCELREGISTRATION).click() //Confirmar clicando em cancelar cadastro
      //afterEach(() => {
        //cy.get(el.LOGOUTLABEL).click()  //deslogando da página
      //});
    }

    erroAlert(){
      cy.clock()
      cy.get(el.SIGNBUTTON, {timeout:5000}).click() //clicar no botão entrar e verificar campos obrigatórios não preenchidos
      cy.get(el.SIGNBUTTON).should('be.visible')
      cy.tick(THREE_SECONDS_IN_MS)
      //cy.get(el.SIGNBUTTON).should('not.be.visible')
    }

    viewPassword(){
      cy.wait(2000)
      cy.get(el.LOGINFIELD,{timeout:5000}).type('cleiton.teixeira@truechange.com.br')
      cy.get(el.PASSWORDFIELD).type('Abc123') //buscando pelo nome final do ID
      cy.get(el.VIEWPASSWORD).click()
    }

    captcha(){
      
    }


}export default new Login();

