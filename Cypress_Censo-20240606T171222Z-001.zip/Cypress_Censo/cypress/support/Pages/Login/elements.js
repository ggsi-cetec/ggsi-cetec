/*Elementos da página para executar as ações
  Page Object Pattern    
*/

export const ELEMENTS = { 

    LOGINFIELD:'.mx-name-Ipt_Login', // botão login
    PASSWORDFIELD:'.mx-name-Ipt_Password', // campo senha
    REMEMBERCHECK:'.checkboxRememberUserName', //Lembra-me
    SIGNBUTTON: '.mx-name-Btn_SignIn1', // clicar para logar no sistema
    MENUBUTTON: '.mx-name-menuBar1-0', //menu para expandir opções de tela
    LOGOUTLABEL: '.mx-name-menuBar1-2', // sair do sistema
    FORGOTLINK: '.mx-name-Btn_Forgot', // esqueceu a sua senha
    EMAILFIELD: '.mx-name-Ipt_Email', // endereço de email para recuperar senha
    RESETBUTTON:'.mx-name-Btn_Recover', //recuperar a senha
    CANCELPASSWORDRESET:'.mx-name-Btn_Cancel', //cancelar redefinição de senha
    ALERTADDRESSEMAIL:'.mx-name-container6',
    SIGNUPBUTTON: '.mx-name-Btn_SignUp',
    NAMEFIELD: '.mx-name-Ipt_name',
    GOTOLOGINPAGE:'.mx-name-Btn_Redirect', //ir para a página de login
    CONTINUEREGISTRATION:'.mx-name-Btn_Signin', //Sing in
    CANCELREGISTRATION:'.mx-name-actionButton2', //cancelar cadastro ou registro
    VIEWPASSWORD:'.icon-show', //visualizar senha
    PAGETITLE: '.mx-name-text41', //título da página inicial seja bem vindo a truechange
    CAPTCHA: '.recaptcha-checkbox-checkmark',
    VALIDATIONMESSAGE: '.mx-name-validationMessage2',
}