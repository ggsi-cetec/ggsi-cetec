// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
Cypress.Commands.add('login', (email, password) => {
cy.visit('/login') // substitua o caminho '/login' pelo caminho para a página de login do seu aplicativo
cy.get('input[name=email]').type(email)
cy.get('input[name=password]').type(password)
cy.get('button[type=submit]').click()
});

/*Cypress.Commands.add('fillRecaptcha', () => {
    cy.window().then(win => {
      const document = win.document;
      const recaptchaCheckbox = document.querySelector('.g-recaptcha-response');
      const recaptchaFrame = document.querySelector('iframe[src*="recaptcha"]');
      const recaptchaFrameContent = recaptchaFrame.contentDocument || recaptchaFrame.contentWindow.document;
      const recaptchaCheckboxFrame = recaptchaFrameContent.querySelector('.recaptcha-checkbox-checkmark');
  
      recaptchaCheckbox.style.display = 'block';
      recaptchaCheckbox.click();
  
      recaptchaCheckboxFrame.click();
    });
  });*/

  Cypress.Commands.add('fillRecaptcha', () => {
    cy.window().then(win => {
      const document = win.document;
      const recaptchaCheckbox = document.querySelector('.g-recaptcha-response');
      const recaptchaFrame = document.querySelector('iframe[src*="recaptcha"]');
      const recaptchaFrameContent = recaptchaFrame.contentDocument || recaptchaFrame.contentWindow.document;
      const recaptchaCheckboxFrame = recaptchaFrameContent.querySelector('.recaptcha-checkbox-checkmark');
  
      recaptchaCheckbox.style.display = 'block';
      recaptchaCheckbox.click();
  
      recaptchaCheckboxFrame.click();
    });
  });
  
  
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })
