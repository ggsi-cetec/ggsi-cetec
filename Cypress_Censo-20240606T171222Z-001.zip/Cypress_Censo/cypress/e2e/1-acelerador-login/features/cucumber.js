const { exec } = require('child_process');
exec('cucumber-js', (err, stdout, stderr) => {
   console.log(stdout);
});