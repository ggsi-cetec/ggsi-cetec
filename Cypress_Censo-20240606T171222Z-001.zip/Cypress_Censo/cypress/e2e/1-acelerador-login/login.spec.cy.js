/// <reference types="cypress" />
import Login from '../../support/Pages/Login'

import { slowCypressDown } from 'cypress-slow-down'

describe('Tela de login', function() {
  beforeEach(function(){
    cy.visit('https://login.devops.truechange.com.br/')
    slowCypressDown(3000)
  })

  afterEach(function(){
    // Limpa o ambiente após cada teste
    cy.clearCookies() //limpa cookies da sessão
    cy.clearLocalStorage() //limpa armazenamento local da sessão
    cy.window().then((win) => {
      win.location.href = 'about:blank'
    })
    //cy.visit('about:blank')
  })

    it('verifica o título da aplicação', function() {
      cy.title().should('include', 'bem-vindos a truechange')
    });

    /*it('Preenche o checkbox do Recaptcha', function() {
      Login.clickcaptcha(); // clicar no checkbox e aguardar até que o Recaptcha seja preenchido
    });
    */

    it('Validar na tela de bem vindos a truechange com usuário válido',function() {
      Login.executeLogin(); //usuário válido
  })

    it('Validar na tela de bem vindos a truechange com usuário inválido',function() {
    Login.executeLoginInvalid(); //usuário inválido
  })


    it('Validar checkbox "Lembrar-me?" na tela de login', function(){
    Login.remember();  //selecionar checkbox
  })

    it('Verificar funcionalidade "Esqueceu a senha?" ', function() {
      Login.forgotPassword(); //Redefinir senha
      
    });

    it('Verificar o cancelamento de redefinição de senha', function() {
      Login.cancelPassword(); //cancelar redefinir senha
      
    });

    it('Verificar mensagem de alert caso clique sem preencher campo email', function() {
      Login.alertAddressEmail(); //exibir alert informando insira um endereço de e-mail

    });

    it.only('Realizar cadastro de usuário na página', function() {
      Login.signUpButton();
  
    });

    it('Verificar cancelamento do cadastro', function() {
      Login.cancelregistration();
      
    });

    it('Exibir mensagem de erro ao submeter o formulário sem preencher os campos obrigatórios', function() {
      Login.erroAlert();
      
    });

    it('Visualizar senha ao clicar no ícone do olho', function() {
      Login.viewPassword();
      
    });

})